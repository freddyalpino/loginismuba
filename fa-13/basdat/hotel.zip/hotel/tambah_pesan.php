<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>SIM HOTEL</title>
  </head>
  <body>
    <a href="index.php">Kembali Ke Menu</a>
    <h1>Pesan Kamar</h1>
    <form action="simpan_pesan.php" method="post">
      <table>
        <tr>
          <td>ID Customer</td>
          <td>:</td>
          <td><input type="text" name="idcustomer"></td>
        </tr>
        <tr>
          <td>ID Kamar</td>
          <td>:</td>
          <td><input type="text" name="idkamar"></td>
        </tr>
        <tr>
          <td>Tanggal Masuk</td>
          <td>:</td>
          <td><input type="date" name="tglmasuk"></td>
        </tr>
        <tr>
          <td>Tanggal Keluar</td>
          <td>:</td>
          <td><input type="date" name="tglkeluar"></td>
        </tr>
        <tr>
          <td colspan="2"></td>
          <td><input type="submit" value="Submit"></td>
        </tr>
      </table>
    </form>
  </body>
</html>
