<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>SIM HOTEL</title>
  </head>
  <body>
    <h1>MENU HOTEL</h1>
    <ul>
      <li>Menu Tambah : </li>
      <ul>
        <li><a href="tambah_customer.php">Tambah Customer</a></li>
        <li><a href="tambah_kategori.php">Tambah Kategori</a></li>
        <li><a href="tambah_kamar.php">Tambah Kamar</a></li>
      </ul>
      <li>Menu Tampil : </li>
      <ul>
        <li><a href="tampil_customer.php">Daftar Customer</a></li>
        <li><a href="tampil_kategori.php">Daftar Kategori</a></li>
        <li><a href="tampil_kamar.php">Daftar Kamar</a></li>
        <li><a href="tampil_pesan.php">Daftar Pesan</a></li>
      </ul>
      <li>Menu Pesan Kamar : </li>
      <ul>
        <li><a href="tambah_pesan.php">Pesan Kamar</a></li>
      </ul>
      <li>Laporan : </li>
      <ul>
        <li><a href="#">Laporan Transaksi Hotel</a></li>
      </ul>
    </ul>
  </body>
</html>
